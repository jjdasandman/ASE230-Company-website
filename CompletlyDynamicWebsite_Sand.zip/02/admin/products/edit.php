<?php
// Include any necessary files and functions
include '../../lib/ReadCSV.php';

// Retrieve data from your data source (e.g., CSV file)
$csvFilePath = '../../data/products.csv';
$products = ReadCSV($csvFilePath);

// Check if the product ID is provided in the query parameters
if (isset($_GET['id'])) {
    $productId = $_GET['id'];
	echo 'productID: '.$productId;

    // Find the product with the specified ID
    $product = null;
    foreach ($products as $p) {
        if ($p[0] == $productId) {
            $product = $p;
            break;
        }
    }
	//echo 'products: <br>';
	//print_R($product);
}

// Handle form submission for updating the product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    // Retrieve the product ID
    $productId = $_POST['id'];

    // Retrieve and update the product details
    $updatedProduct = [

        $_POST['name'], // Name
        $_POST['description'], // Description
        $_POST['applications'], // Applications
        $_POST['icon'], // Icon
    ];
	//print_r($products);
	//echo '<br>';
    // Update the product in the array
foreach ($products as $key => $p) {
    if ($p[0] == $productId) {
        $products[$key] = $updatedProduct;
        break;
    }
}

// Save the updated products to the CSV file
$csvFile = fopen($csvFilePath, 'w');
foreach ($products as $p) {
    fputcsv($csvFile, $p);
}
fclose($csvFile);

    // Redirect to the detail page for the updated product
    header("Location: detail.php?id=" . urlencode($_POST['name']));
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
</head>
<body>
    <h1>Edit Product</h1>

    <?php if ($product) { ?>
        <form method="post" action="">
            <input type="hidden" name="update" value="true">
            <input type="hidden" name="id" value="<?= $product[0] ?>">

            <label for="name">Name:</label>
            <input type="text" name="name" id="name" value="<?= $product[0] ?>" required>

            <label for="description">Description:</label>
            <textarea name="description" id="description" required><?= $product[1] ?></textarea>

            <label for="applications">Applications:</label>
            <textarea name="applications" id="applications" required><?= $product[2] ?></textarea>

            <label for="icon">Icon:</label>
            <input type="text" name="icon" id="icon" value="<?= $product[3] ?>" required> <!-- Include the icon input -->

            <input type="submit" value="Save Changes">
        </form>
    <?php } else { ?>
        <p>Product not found</p>
    <?php } ?>

    <p><a href="index.php">Back to Product List</a></p>
</body>
</html>