<?php
echo "you landed on the create page";

// Include any necessary files and functions
include '../../lib/ReadCSV.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process and validate the form data
    $name = $_POST['name'];
    $title = $_POST['title'];
    $background = $_POST['background'];
    $pic = $_POST['pic'];

    // Validate the data inputs (add more validation as needed)
    if (empty($name) || empty($title) || empty($background) || empty($pic)) {
        // Handle the case where any input is empty
        echo 'All fields must be filled in.';
        exit; // Terminate the script
    }

    // Add the new team member to your data source (e.g., CSV file)
    // Specify the path to your CSV file
    $csvFilePath = '../../data/team.csv';

    // Prepare the data for the new team member as an array
    $newMember = [$name, $title, $background, $pic];

    // Open the CSV file in append mode
    $file = fopen($csvFilePath, 'a');

    // Lock the file for writing
    if (flock($file, LOCK_EX)) {
        // Write the new team member to the CSV file
        fputcsv($file, $newMember);

        // Release the lock
        flock($file, LOCK_UN);

        // Close the file
        fclose($file);
    } else {
        // Handle the case where the file could not be locked (e.g., concurrent access)
        echo 'Unable to add the new team member at this time. Please try again later.';
        exit; // Terminate the script
    }

    // Redirect the user to the index page
    header('Location: index.php');
    exit; // Terminate the script
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create New Team Member</title>
</head>
<body>
    <h1>Create New Team Member</h1>
    <form method="POST" action="">
        <!-- Form fields for creating a new team member -->
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="title">Title:</label>
        <input type="text" name="title" id="title" required>

        <label for="background">Background:</label>
        <textarea name="background" id="background" rows="4" cols="50" required></textarea>

        <label for="pic">Picture URL:</label>
        <input type="text" name="pic" id="pic" required>

        <input type="submit" value="Create Team Member">
    </form>
    <p><a href="index.php">Back to Team List</a></p>
</body>
</html>