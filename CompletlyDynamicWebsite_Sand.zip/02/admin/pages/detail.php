<?php
// Include any necessary files and functions
include '../../lib/ReadCSV.php';
// Retrieve data from your data source (e.g., CSV, database)
$data = ReadCSV('../../data/navbar.csv');

// Check if there's data available
if (!empty($data) && isset($data[0])) {
    // Skip the first row (header)
    array_shift($data);
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Item Details</title>
</head>
<body>
    <h1>Item Details</h1>

    <?php
    // Check if a specific item is requested (e.g., based on query parameters)
    if (isset($_GET['section'])) {
        $requestedSection = $_GET['section'];

        // Find and display the details of the requested item
        $itemFound = false;
        foreach ($data as $item) {
            if ($item[0] === $requestedSection) {
                $itemFound = true;
                echo '<h2>' . htmlspecialchars($item[0]) . '</h2>';
                echo '<p>Item Link: <a href="' . htmlspecialchars($item[1]) . '">' . htmlspecialchars($item[1]) . '</a></p>';
                echo '<p><a href="edit.php?section=' . urlencode($item[0]) . '">Edit</a> | <a href="delete.php?section=' . urlencode($item[0]) . '">Delete</a></p>';
                break; // Exit the loop once the item is found
            }
        }

        if (!$itemFound) {
            echo '<p>Item not found.</p>';
        }
    } else {
        echo '<p>No item selected.</p>';
    }
    ?>

    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>