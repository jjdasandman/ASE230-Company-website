<?php
/* PAGES INDEX */
include '../../lib/ReadPlainText.php';
include '../../lib/ReadCSV.php';
include '../../lib/ReadJSON.php';
$data = ReadCSV('../../data/navbar.csv');
if (!empty($data) && isset($data[0])) {
		// Skip the first row (header)
		array_shift($data);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pages Item List</title>
</head>
<body>
    <h1>Item List</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Item rows will be generated dynamically here -->
			<?php
				//echo var_dump($data);
				// Include your database connection or data retrieval logic here

				// Sample item data (replace this with your actual data retrieval logic)
				$items = [
					['id' => 1, 'name' => 'Item 1'],
					['id' => 2, 'name' => 'Item 2'],
					// Add more items as needed
				];

				// Loop through the items and generate table rows
				if (!empty($data)) {
                foreach ($data as $item) {
					echo '<tr>';
					echo '<td>' . htmlspecialchars($item[0]) . '</td>'; // Use $item[0] for "section"
					//echo '<td><a href="' . htmlspecialchars($item[1]) . '">View Details</a></td>'; // Use $item[1] for "link"
					//echo '<td><a href="' . htmlspecialchars($item[1]) . '">' . htmlspecialchars($item[1]) . '</a></td>';
					echo '<td><a href="detail.php?section=' . urlencode($item[0]) . '">View Details</a></td>';
					echo '</tr>';
				}
				} 
				else {
					// Handle the case where $data is empty (no CSV data found)
					echo '<tr><td colspan="2">No data found.</td></tr>';
				}
			?>
        </tbody>
    </table>
    <p><a href="create.php">
	<button type="button" class="#">click to create</button>
	</a></p>
</body>
</html>