<?php /* AWARDS INDEX */

include '../../lib/ReadJSON.php';
$data = readJSON('../../data/awards.json');

?>
<!DOCTYPE html>
<html>
<head>
    <title>Awards List</title>
</head>
<body>
    <h1>Awards List</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Year</th>
                <th>Award</th>
                <th>Source</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Check if the data is an array and contains "awards"
            if (is_array($data) && isset($data['awards'])) {
                foreach ($data['awards'] as $award) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($award['year']) . '</td>';
                    echo '<td>' . htmlspecialchars($award['award']) . '</td>';
                    echo '<td>' . htmlspecialchars($award['source']) . '</td>';
                    //echo '<td><a href="detail.php?year=' . urlencode($award['year']) . '">View Details</a></td>';
					echo '<td><a href="detail.php?year=' . urlencode($award['year']) . '&award=' . urlencode($award['award']) . '">View Details</a></td>';
                    echo '</tr>';
					
                }
            } else {
                echo '<tr><td colspan="4">No awards found.</td></tr>';
            }
            ?>
        </tbody>
    </table>
    <p><a href="create.php">Create New Award</a></p>
</body>
</html>