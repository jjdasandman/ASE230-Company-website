<?php
/* AWARDS EDIT */

include '../../lib/ReadJSON.php';

// Initialize variables
$editAward = null;
$updatedAward = [];

if (isset($_GET['year'])) {
    $year = $_GET['year'];

    // Read the existing data from the JSON file
    $data = readJSON('../../data/awards.json');

    if (is_array($data) && isset($data['awards'])) {
        foreach ($data['awards'] as $key => $award) {
            if ($award['year'] === $year) {
                $editAward = $award;
                $editIndex = $key;
                break;
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['year']) && isset($_POST['award']) && isset($_POST['source']) && isset($_POST['icon'])) {
        $updatedAward = [
            'year' => $_POST['year'],
            'award' => $_POST['award'],
            'source' => $_POST['source'],
            'icon' => $_POST['icon'],
        ];

        if (is_array($data) && isset($data['awards'])) {
            $data['awards'][$editIndex] = $updatedAward;

            // Encode the data as JSON
            $jsonData = json_encode($data, JSON_PRETTY_PRINT);

            // Save the updated data to the JSON file
            file_put_contents('../../data/awards.json', $jsonData);
        }

        // Redirect to the index page
        header("Location: index.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Award</title>
</head>
<body>
    <h1>Edit Award</h1>
    <form method="POST" action="">
        <label for="year">Year:</label>
        <input type="text" name="year" id="year" value="<?php echo $editAward['year']; ?>" required>

        <label for="award">Award:</label>
        <input type="text" name="award" id="award" value="<?php echo $editAward['award']; ?>" required>

        <label for="source">Source:</label>
        <input type="text" name="source" id="source" value="<?php echo $editAward['source']; ?>" required>

        <label for="icon">Icon:</label>
        <input type="text" name="icon" id="icon" value="<?php echo $editAward['icon']; ?>" required>

        <input type="submit" value="Save Changes">
    </form>
    <p><a href="index.php">Back to Awards List</a></p>
</body>
</html>