<?php
/* AWARDS DETAIL */

include '../../lib/ReadJSON.php';
$data = readJSON('../../data/awards.json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $year = $_POST['year'];
        $award_name = $_POST['award'];
        
        // Redirect to the delete page with the item's year and award as parameters
        header("Location: delete.php?year=$year&award=$award_name");
        exit;
    } elseif (isset($_POST['action']) && $_POST['action'] === 'edit') {
        // Redirect to the edit page
        $year = $_POST['year'];
        header("Location: edit.php?year=$year");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Award Details</title>
</head>
<body>
    <h1>Award Details</h1>
    <?php
    if (isset($_GET['year']) && isset($_GET['award'])) {
        $year = $_GET['year'];
        $award_name = $_GET['award'];
        if (is_array($data) && isset($data['awards'])) {
            foreach ($data['awards'] as $award) {
                if ($award['year'] === $year && $award['award'] === $award_name) {
                    echo '<h2>' . htmlspecialchars($award['year']) . '</h2>';
                    echo '<p>Award: ' . htmlspecialchars($award['award']) . '</p>';
                    echo '<p>Source: ' . htmlspecialchars($award['source']) . '</p>';
                    echo '<p>Icon code: ' . htmlspecialchars($award['icon']) . '</p>';
					?>
                    <form method="post" action="">
                        <input type="hidden" name="year" value="<?php echo $year; ?>">
                        <input type="hidden" name="award" value="<?php echo htmlspecialchars($award_name); ?>">
                        <input type="submit" name="action" value="edit" style="margin-right: 10px;">
                        <input type="submit" name="action" value="delete">
                    </form>
                    <?php
					//echo '<p><a href="edit.php?section=' . urlencode($item[0]) . '">Edit</a> | <a href="delete.php?section=' . urlencode($item[0]) . '">Delete</a></p>';
					break;
                }
            }
        }
    } else {
        echo '<p>No award selected.</p>';
    }
    ?>
    <p><a href="index.php">Back to Awards List</a></p>
</body>
</html>