<?php
	
	include 'lib/ReadPlainText.php';
	include 'lib/ReadCSV.php';
	include 'lib/ReadJSON.php';
	
	//$var = ReadPlainText('','');     <-- template
	$name = ReadPlainText('data/name.txt');
	$overview = ReadPlainText('data/overview.txt'); 
	$mission = ReadPlainText('data/mission.txt'); 
	$data = ReadCSV('data/navbar.csv');
	// Check if the data is not empty and it has at least one row
	if (!empty($data) && isset($data[0])) {
		// Skip the first row (header)
		array_shift($data);
	}
	$products = ReadCSV('data/products.csv');
	// Check if the data is not empty and it has at least one row
	if (!empty($products) && isset($products[0])) {
		// Skip the first row (header)
		array_shift($products);
	}
	$team = ReadCSV('data/team.csv');
	// Check if the data is not empty and it has at least one row
	if (!empty($team) && isset($team[0])) {
		// Skip the first row (header)
		array_shift($team);
	}
	$awards = readJSON('data/awards.JSON');


	
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo $name; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Premium Bootstrap 5 Landing Page Template" />
    <meta name="keywords" content="bootstrap 5, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    <!-- favicon -->
    <link rel="shortcut icon" href="images/logos/TinyTree.jpg" />

    <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />

    <!-- icon -->
    <link href="css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="css/pe-icon-7-stroke.css" />

    <link href="css/style.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="css/colors/cyan.css" id="color-opt">
</head>

<body data-bs-theme="light">

    <!-- STRAT NAVBAR -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-white navbar-custom sticky sticky-white" role="navigation"
        id="navbar">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo text-uppercase" href="index.php">
                <i class="pe-7s-leaf"></i><?php echo $name; ?>
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
                aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu text-dark"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav navbar-center" id="navbar-navlist">
					<?php
						// Loop through the data to generate navbar links dynamically
						foreach ($data as $row) {
							$heading = $row[0];
							$link = $row[1];
							$id = strtolower(str_replace(' ', '', $heading)); // Generate an ID based on heading
							?>
						<li class="nav-item">
							<a data-scroll href="<?php echo $link; ?>" class="nav-link"><?php echo $heading; ?></a>
						</li>
						<?php 
						} 
					?>
                </ul>
                <div class="nav-button ms-auto">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
							<a href="sandbox.php">
                            <button type="button"
                                class="btn btn-primary navbar-btn btn-rounded waves-effect waves-light">Sand's Box</button>
							</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <!-- END NAVBAR -->

    <!--START HOME-->
    <section class="section bg-home home-half" id="home" data-image-src="images/bg-home.jpg">
        <div class="bg-overlay"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-white text-center">
                    <h4 class="home-small-title"><?php echo 'Overview'?></h4>
                    
                    <p class="pt-3 home-desc mx-auto"><?php echo $overview ?></p>
                    <p class="play-shadow mt-4" data-bs-toggle="modal" data-bs-target="#watchvideomodal"><a
                            href="javascript: void(0);" class="play-btn video-play-icon"><i
                                class="pe-7s-play"></i></a></p>

                    <!-- Modal -->
                    <div class="modal fade" id="watchvideomodal"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">
                                <div class="modal-body p-0" style="margin-bottom: -8px;">
                                    <video id="VisaChipCardVideo" class="video-box" controls  width="800" >
                                        <source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4" >
                                        <!--Browser does not support <video> tag -->
                                    </video>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--END HOME-->

    <!-- CLIENT LOGO -->
    <section class="section-sm bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="client-images my-3 my-md-0">
                        <img src="images/clients/1.png" alt="logo-img" class="mx-auto img-fluid d-block">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="client-images my-3 my-md-0">
                        <img src="images/clients/2.png" alt="logo-img" class="mx-auto img-fluid d-block">
                    </div>
                </div>

                <div class="col-md-3 ">
                    <div class="client-images my-3 my-md-0">
                        <img src="images/clients/3.png" alt="logo-img" class="mx-auto img-fluid d-block">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="client-images my-3 my-md-0">
                        <img src="images/clients/4.png" alt="logo-img" class="mx-auto img-fluid d-block">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END CLIENT LOGO -->

    <!--START FEATURES-->
    <section class="section" id="mission">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 order-2 order-lg-1">
                    <div class="features-box mt-5 mt-lg-0">
                        <h3><?php echo ' Our Mission:';?></h3>
                        <p class="text-muted web-desc"><?php echo $mission; ?> </p>
                        <a href="#" class="btn btn-primary mt-4 waves-effect waves-light"><?php echo 'Help Us Help '; ?><i
                                class="pe-7s-smile"></i></a>
                    </div>
                </div>
                <div class="col-lg-7 order-1 order-lg-2">
                    <div class="features-img mx-auto me-lg-0">
                        <img src="images/growth-analytics.svg" alt="macbook image" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--END FEATURES-->

    <!--START SERVICES-->
    <section class="section bg-light " id="products">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1 class="section-title text-center"><?php echo 'Our Products'; ?></h1>
                    <div class="section-title-border mt-3"></div>
                    <p class="section-subtitle text-muted text-center pt-4 font-secondary"><?php echo $mission; ?></p>
                </div>
            </div>
			 
            <div class="row mt-5">
			<?php
				// Loop through CSV data and generate HTML for each product
				foreach ($products as $row) {
					$product = $row[0]; // Product name
					$description = $row[1]; // Description
					$applications = $row[2]; // Applications 
					$icon = $row[3]; //icon path
					?>
				<div class="col-lg-3 mt-4">
                    <div class="services-box">
                        <div class="d-flex">
                            <i class="<?php echo $icon; ?>" ></i>
							
                            <div class="ms-4">
                                <h4><?php echo $product; ?></h4>
                                <p class="pt-2 text-muted"><?php echo $description; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
				<?php } ?>
				
				<?php
				// Loop through CSV data and generate HTML for each product
				foreach ($products as $row) {
					$product = $row[0]; // Product name
					$description = $row[1]; // Description
					$applications = $row[2]; // Applications 
					$icon = $row[3]; //icon path
					?>
				<div class="col-lg-3 mt-4">
                    <div class="services-box">
                        <div class="d-flex">
                            <i class="<?php echo $icon; ?>" ></i>
							
                            <div class="ms-4">
                                <h4><?php echo $product; ?></h4>
                                <p class="pt-2 text-muted"><?php echo $applications; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
				<?php } ?>
				
				
                
				<div class="col-lg-3 mt-4"> <!-- Added a new column with a width of 3 -->
                <div class="services-box">
                    <div class="d-flex">
                            <i class="pe-7s-settings text-primary"></i>
                            <div class="ms-4">
                                <h4>Final Test </h4>
                                <p class="pt-2 text-muted">Separated they live in Bookmarksgrove right at the coast of
                                    the Semantics, and large language ocean neary regelia.</p>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </section>
    <!--START SERVICES-->

    <!--START WEBSITE-DESCRIPTION
    <section class="section bg-web-desc">
        <div class="bg-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="text-white">Build your dream website today</h2>
                    <p class="pt-3 home-desc mx-auto">But nothing the copy said could convince her and so it didn’t take
                        long until a few insidious Copy Writers ambushed her.</p>
                    <a href="#" class="btn btn-light mt-5 waves-effect waves-light">View Plan & Pricing</a>
                </div>
            </div>
        </div>
    </section> 
	END WEBSITE-DESCRIPTION-->

    <!--START ABOUT-US-->
    <section class="section" id="team">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="about-title mx-auto text-center">
                        <h2>Explore our Team!</h2>
                        <p class="text-muted pt-4">Meet our team of dedicated professionals who are passionate about what they do and committed to delivering exceptional results.</p>
                    </div>
                </div>
            </div>
			
			<div class="row justify-content-center mt-5">
			<?php
				// Loop through CSV data and generate HTML for each product
				foreach ($team as $row) {
					$name = $row[0]; // Team mebers name
					$title = $row[1]; // Team designation
					$background = $row[2]; // background synopsis 
					$path = $row[3]; //picture path
					?>
				<div class="col-lg-3 col-sm-6">
                    <div class="team-box text-center">
                        <div class="team-wrapper">
                            <div class="team-member">
                                <img alt="" src="<?php echo $path; ?>" class="img-fluid rounded">
                            </div>
                        </div>
                        <h4 class="team-name"><?php echo $name; ?></h4>
						<h5 class="text-center text-muted"><?php echo $background; ?></h5> 
						<p class="text-uppercase "><?php echo $title; ?></p>
                    </div>

                </div>
				<?php } ?>
			
			
			
            
                

                

            </div>
        </div>
    </section>
    <!--END ABOUT-US-->

    <!--START PRICING
    <section class="section bg-light" id="pricing">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1 class="section-title text-center">Our Pricing</h1>
                    <div class="section-title-border mt-3"></div>
                    <p class="section-subtitle font-secondary text-muted text-center pt-4">Call to action pricing table
                        is really crucial to your for your business website. Make your bids stand-out with amazing
                        options.</p>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-4">
                    <div class="text-center pricing-box">
                        <h4 class="text-uppercase">Economy</h4>
                        <h1>$9.90</h1>
                        <h6 class="text-uppercase text-muted">Billing Per Month</h6>
                        <div class="plan-features mt-5">
                            <p>Bandwidth: <b class="text-primary">1GB</b></p>
                            <p>Onlinespace: <b class="text-primary">50MB</b></p>
                            <p>Support: <b class="text-primary">No</b></p>
                            <p><b class="text-primary">1</b> Domain</p>
                            <p><b class="text-primary">No</b> Hidden Fees</p>
                        </div>
                        <a href="#" class="btn btn-primary waves-effect waves-light mt-5">Join Now</a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text-center pricing-box price-active">
                        <div class="ribbon-box"><span>Popular</span></div>
                        <h4 class="text-uppercase">Deluxe</h4>
                        <h1>$19.90</h1>
                        <h6 class="text-uppercase text-muted">Billing Per Month</h6>
                        <div class="plan-features mt-5">
                            <p>Bandwidth: <b class="text-primary">10GB</b></p>
                            <p>Onlinespace: <b class="text-primary">500MB</b></p>
                            <p>Support: <b class="text-primary">Yes</b></p>
                            <p><b class="text-primary">10</b> Domain</p>
                            <p><b class="text-primary">No</b> Hidden Fees</p>
                        </div>
                        <a href="#" class="btn btn-primary waves-effect waves-light mt-5">Join Now</a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text-center pricing-box">
                        <h4 class="text-uppercase">Ultimate</h4>
                        <h1>$29.90</h1>
                        <h6 class="text-uppercase text-muted">Billing Per Month</h6>
                        <div class="plan-features mt-5">
                            <p>Bandwidth: <b class="text-primary">100GB</b></p>
                            <p>Onlinespace: <b class="text-primary">2 GB</b></p>
                            <p>Support: <b class="text-primary">Yes</b></p>
                            <p><b class="text-primary">Unlimited</b> Domain</p>
                            <p><b class="text-primary">No</b> Hidden Fees</p>
                        </div>
                        <a href="#" class="btn btn-primary waves-effect waves-light mt-5">Join Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
	ENd PRICING-->

    <!--START awards-->
		
    <section class="section" id="awards">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1 class="section-title text-center"><?php echo "What we're proud of!"?></h1>
                    <div class="section-title-border mt-3"></div>
                    <p class="section-subtitle text-muted text-center font-secondary pt-4">Our many prestigious recognitions and awards
                    </p>
                </div>
            </div>
			
            <div class="row mt-5">
			<?php
			if (isset($awards['awards']) && is_array($awards['awards'])) {
				// Loop through the awards array and generate HTML for each award
			foreach ($awards['awards'] as $award) {
					$year = $award['year'];
					$awardName = $award['award'];
					$source = $award['source'];
					$icon = $award['icon'];
					?>
					<div class="col-lg-4 mx-auto">
						<div class="testimonial-box mt-4">
							<div class="testimonial-decs p-4">
								<div class="testi-icon">
									<i class=<?php echo $icon; ?>></i>
								</div>
								<img src="images/testimonials/user-1.jpg" alt=""
									class="img-fluid mx-auto d-block img-thumbnail rounded-circle mb-4">
								<div class="p-1">
									<h5 class="text-center text-uppercase mb-3"><?php echo $awardName." - ";?> <span
											class="text-muted text-capitalize"><?php echo $year; ?></span></h5>
									<p class="text-muted text-center mb-0"><?php echo "source: ".$source; ?></p>
								</div>
								
								
							</div>

						</div>
					</div>
			<?php }
			} 
			else {
			// Handle the case where keys are missing in the data
			echo "Incomplete data for an award.<br><br>";
			echo print_r($awards); // Debugging: Print the contents of $awards
		} ?>
				
				
                
				
				
            </div>
        </div>
    </section>
    <!--END TESTIMONIAL-->

    <!--START GET STARTED
    <section class="section section-lg bg-get-start">
        <div class="bg-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 text-center">
                    <h1 class="get-started-title text-white">Let's Get Started</h1>
                    <div class="section-title-border mt-4 bg-white"></div>
                    <p class="section-subtitle font-secondary text-white text-center pt-4">Far far away, behind the word
                        mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    <a href="#" class="btn btn-light waves-effect mt-4">Get Started <i class="mdi mdi-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>
	END GET STARTED-->

    <!-- START BLOG 
    <section class="section " id="blog">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1 class="section-title text-center">Latest News</h1>
                    <div class="section-title-border mt-3"></div>
                    <p class="section-subtitle text-muted text-center font-secondary pt-4">Separated they live in
                        Bookmarksgrove right at the coast of the Semantics, a large language ocean class at a euismod
                        mus luctus quam.</p>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-lg-4">
                    <div class="blog-box mt-4">
                        <img src="images/blog/img-1.jpg" class="img-fluid rounded" alt="">
                        <div>
                            <h5 class="mt-4 text-muted">UI & UX Design</h5>
                            <h4 class="mt-3"><a href="" class="blog-title"> Doing a cross country road trip </a></h4>
                            <p class="text-muted">She packed her seven versalia, put her initial into the belt and made
                                herself on the way..</p>
                            <div class="mt-3">
                                <a href="" class="read-btn">Read More <i class="mdi mdi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="blog-box mt-4">
                        <img src="images/blog/img-2.jpg" class="img-fluid rounded" alt="">
                        <div>
                            <h5 class="mt-4 text-muted">Digital Marketing</h5>
                            <h4 class="mt-3"><a href="" class="blog-title">New exhibition at our Museum</a></h4>
                            <p class="text-muted">Pityful a rethoric question ran over her cheek, then she continued her
                                way.</p>
                            <div class="mt-3">
                                <a href="" class="read-btn">Read More <i class="mdi mdi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="blog-box mt-4">
                        <img src="images/blog/img-3.jpg" class="img-fluid rounded" alt="">
                        <div>
                            <h5 class="mt-4 text-muted">Travelling</h5>
                            <h4 class="mt-3"><a href="" class="blog-title">Why are so many people..</a></h4>
                            <p class="text-muted">Far far away, behind the word mountains, far from the countries
                                Vokalia and Consonantia.</p>
                            <div class="mt-3">
                                <a href="" class="read-btn">Read More <i class="mdi mdi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </section>
    END BLOG -->

    <!-- CONTACT FORM START-->
    <section class="section " id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1 class="section-title text-center">Get In Touch</h1>
                    <div class="section-title-border mt-3"></div>
                    <p class="section-subtitle text-muted text-center font-secondary pt-4">We thrive when coming up with
                        innovative ideas but also understand that a smart concept should be supported with faucibus
                        sapien odio measurable
                        results.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="mt-4 pt-4">
                        <p class="mt-4"><span class="h5">Office Address 1:</span><br> <span
                                class="text-muted d-block mt-2">4461 Cedar Street Moro, AR 72368</span></p>
                        <p class="mt-4"><span class="h5">Office Address 2:</span><br> <span
                                class="text-muted d-block mt-2">2467 Swick Hill Street <br />New Orleans, LA
                                70171</span></p>
                        <p class="mt-4"><span class="h5">Working Hours:</span><br> <span
                                class="text-muted d-block mt-2">9:00AM To 6:00PM</span></p>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="custom-form mt-4 pt-4">
                        <form method="post" name="myForm" onsubmit="return validateForm()">
                            <p id="error-msg"></p>
                            <div id="simple-msg"></div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group mt-2">
                                        <input name="name" id="name" type="text" class="form-control"
                                            placeholder="Your name*">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group mt-2">
                                        <input name="email" id="email" type="email" class="form-control"
                                            placeholder="Your email*">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group mt-2">
                                        <input type="text" class="form-control" id="subject"
                                            placeholder="Your Subject.." />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group mt-2">
                                        <textarea name="comments" id="comments" rows="4" class="form-control"
                                            placeholder="Your message..."></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 text-end">
                                    <input type="submit" id="submit" name="send" class="submitBnt btn btn-primary"
                                        value="Send Message">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTACT FORM END-->

    <!--START FOOTER-->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 mt-4">
                    <a class="footer-logo text-uppercase" href="#">
                        <i class="mdi mdi-alien"></i>Hiric
                    </a>
                    <div class="text-muted mt-4">
                        <ul class="list-unstyled footer-list">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">About us</a></li>
                            <li><a href="#">Careers</a></li>
                            <li><a href="#">Contact us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 mt-4">
                    <h4>Information</h4>
                    <div class="text-muted mt-4">
                        <ul class="list-unstyled footer-list">
                            <li><a href="#">Terms & Condition</a></li>
                            <li><a href="#">About us</a></li>
                            <li><a href="#">Jobs</a></li>
                            <li><a href="#">Bookmarks</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 mt-4">
                    <h4>Support</h4>
                    <div class="text-muted mt-4">
                        <ul class="list-unstyled footer-list">
                            <li><a href="">FAQ</a></li>
                            <li><a href="">Contact</a></li>
                            <li><a href="">Disscusion</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 mt-4">
                    <h4>Subscribe</h4>
                    <div class="mt-4">
                        <p>In an ideal world this text wouldn’t exist, a client would acknowledge the importance of
                            having web copy before the design starts.</p>
                    </div>
                    <form class="form subscribe">
                        <input placeholder="Email" class="form-control text-white" required>
                        <a href="#" class="submit"><i class="pe-7s-paper-plane"></i></a>
                    </form>
                </div>
            </div>
        </div>
    </footer>
    <!--END FOOTER-->

    <!--START FOOTER ALTER-->
    <div class="footer-alt">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="float-sm-start pull-none">
                        <p class="copy-rights  mb-3 mb-sm-0">
                            <script>
                                document.write(new Date().getFullYear())
                            </script> © Hiric - Themesbrand
                        </p>
                    </div>
                    <div class="float-sm-end pull-none copyright">
                        <ul class="list-inline d-flex flex-wrap social m-0">
                            <li class="list-inline-item"><a href="" class="social-icon"><i
                                        class="mdi mdi-facebook"></i></a></li>
                            <li class="list-inline-item"><a href="" class="social-icon"><i
                                        class="mdi mdi-twitter"></i></a></li>
                            <li class="list-inline-item"><a href="" class="social-icon"><i
                                        class="mdi mdi-linkedin"></i></a></li>
                            <li class="list-inline-item"><a href="" class="social-icon"><i
                                        class="mdi mdi-google-plus"></i></a></li>
                            <li class="list-inline-item"><a href="" class="social-icon"><i
                                        class="mdi mdi-microsoft-xbox"></i></a></li>
                        </ul>
                    </div>
                    <!-- <div class="clearfix"></div> -->
                </div>
            </div>
        </div>
    </div>
    <!--END FOOTER ALTER-->

    <!-- Style switcher -->
    <div id="style-switcher">
        <div>
            <h3 class="">Select your color</h3>
            <ul class="pattern">
                <li>
                    <a class="color1" href="javascript: void(0);" onclick="setColor('cyan')"></a>
                </li>
                <li>
                    <a class="color2" href="javascript: void(0);" onclick="setColor('red')"></a>
                </li>
                <li>
                    <a class="color3" href="javascript: void(0);" onclick="setColor('green')"></a>
                </li>
                <li>
                    <a class="color4" href="javascript: void(0);" onclick="setColor('pink')"></a>
                </li>
                <li>
                    <a class="color5" href="javascript: void(0);" onclick="setColor('blue')"></a>
                </li>
                <li>
                    <a class="color6" href="javascript: void(0);" onclick="setColor('purple')"></a>
                </li>
                <li>
                    <a class="color7" href="javascript: void(0);" onclick="setColor('orange')"></a>
                </li>
                <li>
                    <a class="color8" href="javascript: void(0);" onclick="setColor('yellow')"></a>
                </li>
            </ul>
        </div>
        <div class="bottom">
            <a href="javascript: void(0);" id="mode" class="mode-btn text-white">
                <i class="mdi mdi-weather-sunny bx-spin mode-light"></i>
                <i class="mdi mdi-moon-waning-crescent mode-dark"></i>
            </a>
            <a href="javascript: void(0);" class="settings" onclick="toggleSwitcher()"><i
                    class="mdi mdi-cog  mdi-spin"></i></a>
        </div>
    </div>
    <!-- end Style switcher -->

    <!-- javascript -->
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/smooth-scroll.polyfills.min.js"></script>
    <script src="js/gumshoe.polyfills.min.js"></script>
    <!-- Main Js -->
    <script src="js/app.js"></script>
</body>

</html>